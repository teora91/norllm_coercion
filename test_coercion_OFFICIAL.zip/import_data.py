from utils import *


def import_data():
    list_lemma_inflected = pd.read_csv("../data_for_task/list_lemma_coercion_inflected_updated_02-12-24.csv")

    # load (NCC) entity_verb_association.csv, the file with pmi scores from NCC associated with enitites 
    # entity_verb_association_NCC = pd.read_csv("../NCC_pmi_score/entity_verb_association.csv", delimiter=",", dtype=str)
    with open("../data_for_task/entity_verb_association_updated_02-12-24.json", "r") as file:
        entity_verb_association_NCC = json.load(file)

    entity_verb_association_NoTenTen = pd.read_csv("../data_for_task/entity_verb_association_NoTenTen_updated_02-12-24.csv")

    return list_lemma_inflected, entity_verb_association_NCC, entity_verb_association_NoTenTen