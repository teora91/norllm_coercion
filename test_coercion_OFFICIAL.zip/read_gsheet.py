import gspread
from google.oauth2 import service_account
import json

def read_gsheet(gheet_path):
    # Load the JSON key file contents
    with open("organic-area-373313-bfd58d4eed93.json", 'r') as json_file:
        service_account_info = json.load(json_file)

    # Create credentials from the loaded JSON data
    credentials = service_account.Credentials.from_service_account_info(service_account_info)

    scope = ['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive']
    creds_with_scope = credentials.with_scopes(scope)

    client = gspread.authorize(creds_with_scope)

    # spreadsheet = client.open_by_url('https://docs.google.com/spreadsheets/d/1J_gI1RHpfr2WjcNkLadCWdXCKPCVXChoVnABRuYYIiI/edit#gid=1256451995')
    spreadsheet = client.open_by_url(gheet_path)


    #Next, zoom in on the worksheet (the tab in the Google spreadsheet) you want to get the data from. Let’s get the first workspace using the index 0:
    # Open the worksheet
    worksheet = spreadsheet.get_worksheet(1)  # Replace with the correct sheet index or name


    # # First, get all the records as a JSON:
    records_data = worksheet.get_all_values()
    
    return records_data

