#!/bin/bash
Getting the length of the json dictionary

len_=$(jq 'length' llm_list_nor.json)
echo Total grouped models: $len_

echo Classification Started...
for n in $(seq 1 1); #$len_);
do
    # python main.py -idx 1 -c true #$n
    # python main.py -idx 1 -c false #$n
    python main.py -idx 4 -c true #$n
    python main.py -idx 4 -c false #$n

    # python main.py -idx 4 #$n

    
done
echo Merging Results...
python merging_results.py

echo Extracting Predictions...
python extract_predictions.py


echo SCRIPT ENDED



##############TO BE CONTINUED

# REPO_PATH="norllm_coercion"

# if [ -d $REPO_PATH ]; then
#     echo "Repositopry folder already exists. Pulling latest changes..."
# else
#     echo "Repository folder does not exist. Cloning it from Github..."
#     git clone https://github.com/teora91/norllm_coercion
# fi
# cd norllm_coercion/results

# touch empty_file.csv #filler to avoid errors with the mv command
# mv *.csv ../old_results
# cd ../../
# cp results_test_coercion* norllm_coercion/results

# git add "norllm_coercion"
# git commit -m "Added norllm_coercion"
# git push origin "https://github.com/teora91/norllm_coercion/tree/main"
