# coding=utf-8

from utils import *
import MLM_model, CAUSAL_LM_model
from import_data import import_data
from fill_mask_mlm import fill_mask_mlm


#Importing data
list_lemma_inflected, entity_verb_association_NCC, entity_verb_association_NoTenTen = import_data()

# Converting model name into absolute path for WIndows_ Goal delete model for space improvement

def get_experimental_items(): #get gsheet
    #get experimental item with context
    gheet_path = 'https://docs.google.com/spreadsheets/d/1J_gI1RHpfr2WjcNkLadCWdXCKPCVXChoVnABRuYYIiI/edit#gid=1256451995'

    records_data = read_gsheet(gheet_path)

    df = pd.DataFrame.from_dict(records_data)
    df.columns = df.iloc[4]
    df = df.iloc[5:]
    df = df[~(df["cat_letter"].str.contains('a'))]
    df = df[df["item"]!="fane-n"]
    return df
    

def assembly_sentence(items):
    condition_letter = items['cat_letter']
    entity_lemma = re.sub("-\w+", "", items['item'])
    event_top_predict = items['pred_event']
    subj = items['SUBJ']
    sent = items['PRE_CONTEXT'] + " " + items['SUBJ'].capitalize() + " " + '[VERB]' + " " + '[PREP]' + " " + items['ARG'] + " " + items['POST_CRIT'] + items['EOS']
    return sent, subj, event_top_predict, entity_lemma, condition_letter


def model_name_converter(model_name):
    model_hub = re.sub("^", "models--", model_name)
    model_hub = re.sub("/", "--", model_hub)
    model_hub = re.sub("^", "C:/Users/mattera/.cache/huggingface/hub/", model_hub)

    return model_hub


def flatten_list(list_):
    new_list = []
    for i in list_:
        for x in i:
            new_list.append(x)
    return new_list

    
def start_classification(model, model_type, tokenizer, with_context,  model_ltg): #preparing sentences to be tested
    list_model_used = []
    list_entities_ = []
    list_predictions = []
    list_logits = []
    list_masked_tokens_found = []
    output_text = [] #list of sentences in output
    list_subjects, list_verbs, list_prepositions = [], [], []
    soft_max = []
    list_same_index_logits_softmax = []
    condition_letter_list = [] #only for classification with context
    
    subjects = [("Kim", 0)]
    verbs = ["begynte", "startet", "fortsatte", "avsluttet"]
    prepositions = ["på", "med", ""]

    if model_type == 0:
        print("Model type chosen: BERT")
        
        if with_context == False:
            print("Classification WITHOUT context")
        
            for entity_lemma, entity_inflected in zip(entity_verb_association_NCC, list_lemma_inflected["0"].tolist()): 

                for subj in subjects:
                    subj = subj[0]
                    for verb in verbs:
                        for prep in prepositions:
                            if model_ltg == 1:   
                                sentence = f"{subj} {verb} {prep} {entity_inflected}. Det som {subj} {verb} å gjøre, var å[MASK].".replace("  ", " ")
                            else:
                                sentence = f"{subj} {verb} {prep} {entity_inflected}. Det som {subj} {verb} å gjøre, var å [MASK].".replace("  ", " ")
                            
                            print(sentence) ###   
                            output_text_list, list_prob_events, list_probabilities, list_probabilities_logits, masked_token_found, same_index_logits_softmax = \
                            fill_mask_mlm(tokenizer, model, sentence,entity_lemma)
                        
                            list_model_used.append(model.model_name)
                            output_text.append(output_text_list)
                            list_entities_.append(entity_lemma)
                            list_predictions.append(list_prob_events)
                            list_subjects.append(subj)
                            list_verbs.append(verb)
                            list_prepositions.append(prep)
                            soft_max.append(list_probabilities)
                            list_logits.append(list_probabilities_logits)
                            list_masked_tokens_found.append(masked_token_found)
                            list_same_index_logits_softmax.append(same_index_logits_softmax)
                    
            return list_model_used, output_text, list_entities_, list_predictions, list_subjects, list_verbs, list_prepositions, soft_max, list_logits, list_masked_tokens_found, list_same_index_logits_softmax, condition_letter_list


        
        elif with_context == True:
            df_dataset_coercion = get_experimental_items() #call the dataset with experimental items
            print("Classification WITH context")
            
            for idx, items in df_dataset_coercion.iterrows():
                sent, subj, event_top_predict, entity_lemma, condition_letter  = assembly_sentence(items)

                for verb in verbs:
                    for prep in prepositions:

                        sent2 = sent.replace('[VERB]', verb).replace('[PREP]', prep).replace('[SUBJ]', subj.capitalize())

                        sent3 = re.sub("(\s)?%", "", sent2)
                        sent3 = re.sub("^\s", "", sent3)


                        if model_ltg == 1: 

                            sentence = sent3 + f" Det som {subj} {verb} å gjøre, var å[MASK]."
                        else:
                            sentence = sent3 + f" Det som {subj} {verb} å gjøre, var å [MASK]."

                        sentence = re.sub("\s\s", " ", sentence)

                        print("SENT: ", sentence) ###
                        

                        output_text_list, list_prob_events, list_probabilities, list_probabilities_logits, masked_token_found, same_index_logits_softmax = \
                            fill_mask_mlm(tokenizer, model, sentence,entity_lemma)
                        
                        list_model_used.append(model.model_name)
                        output_text.append(output_text_list)
                        list_entities_.append(entity_lemma)
                        list_predictions.append(list_prob_events)
                        list_subjects.append(subj)
                        list_verbs.append(verb)
                        list_prepositions.append(prep)
                        soft_max.append(list_probabilities)
                        list_logits.append(list_probabilities_logits)
                        list_masked_tokens_found.append(masked_token_found)
                        list_same_index_logits_softmax.append(same_index_logits_softmax)
                        condition_letter_list.append(condition_letter)


            return list_model_used, output_text, list_entities_, list_predictions, list_subjects, list_verbs, list_prepositions, soft_max, list_logits, list_masked_tokens_found, list_same_index_logits_softmax, condition_letter_list

            
        
    elif model_type == 1:
        print("Model type chosen: GPT")
        if with_context == False:
            print("Classification WITHOUT context")

        
            for entity_lemma, entity_inflected in zip(entity_verb_association_NCC, list_lemma_inflected["0"].tolist()): 

                for subj in subjects:
                    subj = subj[0]

                    for verb in verbs:
                        for prep in prepositions:
                            sentence = f"{subj} {verb} {prep} {entity_inflected}. Det som {subj} begynte å gjøre, var å".replace("  ", " ")
                            print(sentence)
                            sequence_prediction, sequence_prediction_softmax, sequence_prediction_logits, output_text_list, list_same_index_logits_softmax_list = \
                                model.fill_mask_gpt(sentence, entity_lemma)
                            
                            list_model_used.append(model.model_name)
                            list_entities_.append(entity_lemma)
                            list_predictions.append(sequence_prediction)
                            list_subjects.append(subj)
                            list_verbs.append(verb)
                            list_prepositions.append(prep)
                            soft_max.append(sequence_prediction_softmax)
                            output_text.append(output_text_list)
                            list_logits.append(sequence_prediction_logits)
                            list_same_index_logits_softmax.append(list_same_index_logits_softmax_list)
                            list_masked_tokens_found.append("not_necessary")
            return list_model_used, output_text, list_entities_, list_predictions, list_subjects, list_verbs, list_prepositions, soft_max, list_logits, list_masked_tokens_found, list_same_index_logits_softmax, condition_letter_list

                            
        elif with_context == True:
            df_dataset_coercion = get_experimental_items() #call the dataset with experimental items
            print("Classification WITH context")

            for idx, items in df_dataset_coercion.iterrows():
                sent, subj, event_top_predict, entity_lemma, condition_letter  = assembly_sentence(items)

                for verb in verbs:
                    for prep in prepositions:

                        sent2 = sent.replace('[VERB]', verb).replace('[PREP]', prep).replace('[SUBJ]', subj.capitalize())

                        sent3 = re.sub("(\s)?%", "", sent2)
                        sent3 = re.sub("^\s", "", sent3)

                        sentence = sent3 + f" Det som {subj} {verb} å gjøre, var å"

                        sentence = re.sub("\s\s", " ", sentence)

                        print("SENT: ", sentence) ###

                        sequence_prediction, sequence_prediction_softmax, sequence_prediction_logits, output_text_list, list_same_index_logits_softmax_list = \
                                model.fill_mask_gpt(sentence, entity_lemma)
                        list_model_used.append(model.model_name)
                        list_entities_.append(entity_lemma)
                        list_predictions.append(sequence_prediction)
                        list_subjects.append(subj)
                        list_verbs.append(verb)
                        list_prepositions.append(prep)
                        soft_max.append(sequence_prediction_softmax)
                        output_text.append(output_text_list)
                        list_logits.append(sequence_prediction_logits)
                        condition_letter_list.append(condition_letter)



            

            return list_model_used, output_text, list_entities_, list_predictions, list_subjects, list_verbs, list_prepositions, soft_max, list_logits, list_masked_tokens_found, list_same_index_logits_softmax, condition_letter_list
    
def main():
    output_text_df = []
    union_list_model_used = []
    list_entities_df = []
    list_prediction_df = []
    df_list_prepositions, df_list_subjects, df_list_verbs = [], [], []
    df_soft_max = []
    df_logits = []
    df_list_mask_tokens_found = []
    df_same_index_logits_softmax = []
    df_condition_letter_list = []

    def str2bool(value):
        """Convert string to boolean."""
        if isinstance(value, bool):
            return value
        if value.lower() in ('true', 't', 'yes', '1'):
            return True
        elif value.lower() in ('false', 'f', 'no', '0'):
            return False
        else:
            raise argparse.ArgumentTypeError("Boolean value expected.")

    parser = argparse.ArgumentParser(description=None)

    parser.add_argument(
        "-idx", "--index_group",
        type=int,
        required=True
    )

    parser.add_argument(
        "-c", "--context",
        type=str2bool,  # Use the custom str2bool function
        required=True,
        help="Specify True or False for the context"
    )

    args = parser.parse_args()    
    
    if args.index_group:
        selected_model_index = args.index_group
        print(f"Group of model chosen -> {args.index_group}")
        
        with open('llm_list_nor.json', 'r') as file:
            model_list = json.load(file)[str(selected_model_index)]

        
        with_context = args.context
        print(f"Group of model chosen -> {with_context}")

        
        

    folder_path = f"results_coercion_{today}"
    path_data = folder_path + f"/results_test_coercion_no_context_OFFICIAL_PORTEN_incl_updated_{today}_BETA_part_{args.index_group}_with_context_{with_context}.csv"
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
        print(f"New folder for results created: {folder_path}")
        
    
    for model in model_list:
        print("Running Model: ", model[0])
        print()
    
        if model[1] == 0:
            print(model[1])
            #FILL MASK FOR BERT MODELS
            model_hub = model_name_converter(model[0])
            model_mlm = MLM_model.MLMHeadModel(model[0])

            #if ltg models they need to modify the string where the mask token is found
            model_ltg = model[2]


            list_model_used, output_text, list_entities_, list_predictions, list_subjects, list_verbs, list_prepositions, soft_max, list_logits, list_masked_tokens_found, list_same_index_logits_softmax, condition_letter_list = start_classification(model_mlm, model[1], model_mlm.tokenizer, with_context, model_ltg=False)

            union_list_model_used.append(list_model_used)
            output_text_df.append(output_text)
            list_entities_df.append(list_entities_)
            list_prediction_df.append(list_predictions)
            df_list_subjects.append(list_subjects)
            df_list_verbs.append(list_verbs)
            df_list_prepositions.append(list_prepositions)
            df_soft_max.append(soft_max)
            df_logits.append(list_logits)
            df_list_mask_tokens_found.append(list_masked_tokens_found)
            df_same_index_logits_softmax.append(list_same_index_logits_softmax)
            df_condition_letter_list.append(condition_letter_list)

        if model[1] == 1:
            print(model[1])
            # GPT MODELS
            model_hub = model_name_converter(model[0])
            model_gpt = CAUSAL_LM_model.LMHeadModel(model[0])
                        
            list_model_used, output_text,  list_entities_, list_predictions, list_subjects, list_verbs, list_prepositions, soft_max, list_logits, list_masked_tokens_found, list_same_index_logits_softmax, condition_letter_list = start_classification(model_gpt, model[1], model_gpt.tokenizer, with_context, model_ltg=False)
            
            union_list_model_used.append(list_model_used)
            output_text_df.append(output_text)
            list_entities_df.append(list_entities_)
            list_prediction_df.append(list_predictions)
            df_list_prepositions.append(list_prepositions)
            df_list_subjects.append(list_subjects)
            df_list_verbs.append(list_verbs)
            df_soft_max.append(soft_max)
            df_logits.append(list_logits)
            df_list_mask_tokens_found.append(list_masked_tokens_found)
            df_same_index_logits_softmax.append(list_same_index_logits_softmax)
            df_condition_letter_list.append(condition_letter_list)

            
            
            
    output_text_df = flatten_list(output_text_df)
    list_entities_df_ = flatten_list(list_entities_df)
    list_prediction_df_ = flatten_list(list_prediction_df)
    df_list_prepositions = flatten_list(df_list_prepositions)
    df_list_subjects = flatten_list(df_list_subjects)
    df_list_verbs = flatten_list(df_list_verbs)
    df_soft_max = flatten_list(df_soft_max)
    df_logits = flatten_list(df_logits)
    df_list_mask_tokens_found = flatten_list(df_list_mask_tokens_found)
    df_same_index_logits_softmax = flatten_list(df_same_index_logits_softmax)
    df_condition_letter_list = flatten_list(df_condition_letter_list)
    model_list_df = []
    for x in union_list_model_used:
        c = []
        c.append(x[0]) 
        for i in c * int(len(list_entities_df_)/len(model_list)):
            model_list_df.append(i)

    print("Creation Dataframe ...")
    print("Length Dataframe", len(model_list_df))
    columns_df_final = ["model_name", "condition letter", "entities", "subject", "verb" ,"preposition", "predicted_events","soft_max", "logits", "output_text_predicted", "masked_tokens", "same_index_logits_sftmax"]
    results_df = pd.DataFrame([model_list_df, df_condition_letter_list, list_entities_df_, df_list_subjects, df_list_verbs, df_list_prepositions,list_prediction_df_, df_soft_max, df_logits, output_text_df,df_list_mask_tokens_found, df_same_index_logits_softmax ], index=columns_df_final).T

    print("Saving DataFrame ...")
    
    
    results_df.to_csv(path_data, index=False)
    


if __name__ == '__main__':
    main()
    print("Done")
